
	//	Berker ÖNER 150122018

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Product {

	private String productName;
	private java.util.Calendar saleDate;
	private double price;
	private Calendar transactionDate;
	
	public Product(String sName, java.util.Calendar sDate, double price) {
		
		this.productName = sName;
		this.saleDate = sDate;
		this.price = price;
		this.transactionDate = sDate;
	}
	
	public String getProductName() {
		return productName;
	}
	
	public void setProductName(String sName) {
		this.productName = sName;
	}
	
	public Calendar getSaleDate() {
		return saleDate;
	}
	
	public void setSaleDate(Calendar sDate) {
		this.saleDate = sDate;
	}
	
	public double getPrice() {
		return price;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public Calendar getTransactionDate() {
		return transactionDate;
	}
	
	public void setTransactionDate(Calendar transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	@Override
	public String toString() {
		
		if(transactionDate != null) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDate = dateFormat.format(transactionDate.getTime());
		return "Product [productName=" + productName + ", transactionDate=" + formattedDate + ", price=" + price + "]]";
		}
		
		else {
			return "Invalid Transaction Date !";
		}
	}
	
}
