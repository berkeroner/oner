
	//	Berker ÖNER 150122018

import java.util.ArrayList;
import java.util.Calendar;

public class Manager extends Employee {
	
	
	private ArrayList<RegularEmployee> employees;
	private ArrayList<RegularEmployee> regularEmployees;
	private double bonusBadget;

	public Manager(int id, String firstName, String lastName, String gender,
			Calendar birthDate, String maritalStatus, String hasDriverLicence, double
			salary, Calendar hireDate, Department department, double bonusBudget) {
		
		super(id, firstName, lastName, gender, birthDate, maritalStatus, hasDriverLicence, salary, hireDate, department);
		this.employees = new ArrayList<>();
		this.regularEmployees = new ArrayList<>();
		this.bonusBadget = bonusBadget;
		
	}
	
	public Manager(Employee employee, double bonusBadget) {
		
		super(employee.getId(), employee.getFirstName(), employee.getLastName(), employee.getGender(), employee.getBirthDate(), employee.getMaritalStatus(), employee.getHasDriverLicence(), employee.getSalary(),
				employee.getHireDate(), employee.getDepartment());
		this.employees = new ArrayList<>();
		this.regularEmployees = new ArrayList<>();
		this.bonusBadget = bonusBadget;
	}
	
	
	public void addEmployee(RegularEmployee regularEmployee) {
		regularEmployees.add(regularEmployee);
	}
	
	public void removeEmployee(RegularEmployee regularEmployee) {
		regularEmployees.remove(regularEmployee);
	}
	
	public ArrayList<RegularEmployee> getRegularEmployees(){
		return regularEmployees;
	}
	
	public void setRegularEmployees(ArrayList<RegularEmployee> regularEmployees) {
		this.regularEmployees = regularEmployees;
	}
	
	public double getBonusBadget() {
		return bonusBadget * getSalary();
	}
	
	public void setBonusBadget(double bonusBadget) {
		this.bonusBadget = bonusBadget;
	}
	
	public double distributeBonusBadget() {
		
		double totalPerformanceScore = 0;
		
		for(RegularEmployee employee : regularEmployees) {
			totalPerformanceScore += employee.getPerformanceScore();
		}
		double unit = bonusBadget / totalPerformanceScore;
		
		for(RegularEmployee employee : regularEmployees) {
			
			double bonus = unit * employee.getPerformanceScore();
			employee.setBonus(bonus);
			return bonus;
		}
		return 0;
	}
	
	@Override
	public String toString() {
		StringBuilder managerInfo = new StringBuilder("\tManager [id: " + getId() + ", " + getFirstName() + " " + getLastName() + "\n");
        managerInfo.append("\t\t# of Employees: ").append(employees.size()).append("]\n");

        
        int count = 1;
        for (Employee employee : employees) {
            managerInfo.append("\t\t").append(count++).append(". ").append(employee.getClass().getSimpleName()).append("\n");
            managerInfo.append("\t\t\t").append(employee.toString()).append("\n");
        }

        return managerInfo.toString();
	}

	public void createEmployeeList(ArrayList<Employee> employees2) {
		// TODO Auto-generated method stub
		
	}

	public ArrayList<Employee> getEmployees() {
		
		return null;
	}
	
}
