
import java.util.ArrayList;

public class Department {

	private int departmentId;
	private String departmentName;
	private Manager manager;
    private ArrayList<Employee> employees;
	
	public Department(int departmentId, String departmentName) {
		
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.employees = new ArrayList<>();
		
	}
	
	public void setDepartmentId(int departmentId) {
		
		if(departmentId > 0) {
			this.departmentId = departmentId;
		}
		else {
			throw new IllegalArgumentException("Invalid ID !");
		}
	}
	
	public int getDepartmentId() {
		return departmentId;
	}
	
	public void setDepartmentName(String departmentName) {
		
		if(departmentName.length() < 3) {
			throw new IllegalArgumentException("Invalid Department Name !");
		}
		else {
			this.departmentName = departmentName;
		}
	}
	
	public String getDepartmentName() {
		return departmentName;
	}
	
	public Manager getManager() {
	    return this.getManager();
	}
	
	public ArrayList<Employee> getEmployees() {
	    return employees;
	}

	
	@Override
	public String toString() {
	    StringBuilder result = new StringBuilder();
	    result.append("************************************************\n");
	    result.append("Department [departmentId=").append(departmentId).append(", departmentName=").append(departmentName).append("]\n");

	    if (manager != null) {
	        result.append("\tManager: ").append(manager).append("\n");
	    }

	    if (!employees.isEmpty()) {
	        result.append("\tEmployees:\n");
	        for (Employee employee : employees) {
	            result.append("\t\t").append(employee).append("\n");
	        }
	    }

	    return result.toString();
	}

	
}
