
import java.util.Calendar;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Customer extends Person{

	private ArrayList<Product> products;
	
	public Customer(int id, String firstName, String lastName, String gender,
			Calendar birthDate, String maritalStatus, String hasDriverLicence,
			ArrayList<Product> customerProducts1) {
		
		super(id, firstName, lastName, gender, birthDate, maritalStatus, hasDriverLicence);
		this.products = customerProducts1;
	}
	
	public Customer(Person person, ArrayList<Product> products) {
		
		super(person.getId(), person.getFirstName(), person.getLastName(), person.getGender(), person.getBirthDate(), 
				person.getMaritalStatus(), person.getHasDriverLicence());
		this.products = products;
	}
	
	public ArrayList<Product> getProducts(){
		return products;
	}
	
	public void setProducts(ArrayList<Product> products) {
		this.products = products;
	}
	
	@Override
	public String toString() {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		String formattedDate = dateFormat.format(getBirthDate().getTime());
		
		return "Customer [id:" + getId() + " products=" + products;
	}
}
