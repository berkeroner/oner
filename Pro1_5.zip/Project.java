
	//	Berker ÖNER 150122018

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Project {

	private String projectName;
	private java.util.Calendar startDate;
	private boolean state;
	
	public Project(String pName, Calendar startDate, boolean state) {
		
		this.projectName = pName;
		this.startDate = startDate;
		this.state = state;
		
	}
	
	public void setState(String state) {
		
		if(state.equalsIgnoreCase("open")) {
			this.state = true;
		}
		else if(state.equalsIgnoreCase("close")) {
			this.state = false;
		}
		else {
			throw new IllegalArgumentException("Invalid state value !");
		}
		
	}
	
	public String getState() {
		
		if(state = true) {
			return "Open";
		}
		else {
			return "Close";
		}
	}
	
	public void close() {
		state = false;
	}
	
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public String getProjectName() {
		return projectName;
	}
	
	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}
	
	public Calendar getStartDate() {
		return startDate;
	}
	
	public void setState(boolean state) {
		this.state = state;
	}
	
	public boolean isState() {
		return state;
	}
	
	@Override
	public String toString() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String startDateStr = dateFormat.format(startDate.getTime());
        return "Project [projectName=" + projectName + ", startDate=" + startDateStr + ", state=" + (state ? "true" : "false") + "]]";
	}

}
