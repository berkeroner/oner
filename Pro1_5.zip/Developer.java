
	//	Berker ÖNER 150122018

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Developer extends RegularEmployee {
	
	private ArrayList<Project> projects;
	public static int numberOfDevelopers = 0;

	public Developer(int id, String firstName, String lastName, String gender,
			Calendar birthDate, String maritalStatus, String hasDriverLicence, double
			salary, Calendar hireDate, Department department, double pScore,
			ArrayList<Project> p) {
		
		super(id, firstName, lastName, gender, birthDate, maritalStatus, hasDriverLicence, salary, hireDate, department, pScore);
		this.projects = p;
		numberOfDevelopers++;
	}
	
	public Developer(RegularEmployee re, ArrayList<Project> p) {
		
		super(re.getId(), re.getFirstName(), re.getLastName(), re.getGender(), re.getBirthDate(), re.getMaritalStatus(), re.getHasDriverLicence(),
				re.getSalary(), re.getHireDate(), re.getDepartment(), re.getPerformanceScore());
		this.projects = p;
		numberOfDevelopers++;
	}
	
	public boolean addProject(Project s) {
		return projects.add(s);
	}
	
	public boolean removeProject(Project s) {
		return projects.remove(s);
	}
	
	public ArrayList<Project> getProjects(){
		return projects;
	}
	
	public void setProjects(ArrayList<Project> projects) {
		this.projects = projects;
	}
	
	public static int getNumberOfDevelopers() {
		return numberOfDevelopers;
	}
	
	@Override
	public String toString() {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String formattedDate = dateFormat.format(getHireDate().getTime());
		
		return "\t\t\t1. Developer\n" + "\t\t\t\tPerson Info [id=" + super.getId() + ", firstName=" + super.getFirstName() + ", lastName=" +super.getLastName() + ", gender=" + super.getGender() + "]\n" + 
		"\t\t\t\tEmployee Info [salary=" + getSalary() + ", hireDate=" + formattedDate + "]\n" + 
		"\t\t\t\tRegularEmployee Info [performanceScore=" + getPerformanceScore() + ", bonus=" + getBonus() + "]";
				
	}

	
}
