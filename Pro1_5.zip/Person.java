
	//	Berker ÖNER 150122018


import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Person {

	private int id;
	private String firstName;
	private String lastName;
	private byte gender;
	private java.util.Calendar birthDate;
	private byte maritalStatus;
	private boolean hasDriverLicence;
	
	public Person(int id, String firstName, String lastName, String gender,
			Calendar birthDate, String maritalStatus, String hasDriverLicence) {
		
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.birthDate = birthDate;
		setGender(gender);
		setMaritalStatus(maritalStatus);
		setHasDriverLicence(hasDriverLicence);

	}
	
	public void setGender(String gender) {
		
		if(gender.equalsIgnoreCase("man")) {
			this.gender = 1;
		}
		
		else if(gender.equalsIgnoreCase("woman")) {
			this.gender = 2;
		}
		
		else {
			throw new IllegalArgumentException("Only Man or Woman !");
		}
		
	}
	
	public String getGender() {
		
		if(gender == 1) {
			return "Man";
		}		
		else {
			return "Woman";
		}				
	}
	
	public void setMaritalStatus(String status) {
		
		if(status.equalsIgnoreCase("single")) {
			this.maritalStatus = 1;
		}		
		else if(status.equalsIgnoreCase("married")) {
			this.maritalStatus = 2;
		}		
		else {
			throw new IllegalArgumentException("Only Single or Married !");
		}		
	}
	
	public String getMaritalStatus() {
		
		if(maritalStatus == 1) {
			return "Single";
		}		
		else{
			return "Married";
		}
	}
	
	public void setHasDriverLicence(String info) {
		
		if(info.equalsIgnoreCase("yes")) {
			this.hasDriverLicence = true;
		}
		else if(info.equalsIgnoreCase("no")){
			this.hasDriverLicence = false;
		}
	}
	
	public String getHasDriverLicence() {
		
		if(hasDriverLicence == true) {
			return "Yes";
		}
		else {
			return "No";
		}
	}
	
	@Override
	public String toString() {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String formattedDate = dateFormat.format(birthDate.getTime());
		
		return "Person [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + getGender() +
				", birthDate=" + formattedDate + ", maritalStatus=" + getMaritalStatus() +
				", hasDriverLicence=" + getHasDriverLicence() + "]" ;
	}

	public int getId() {
		
		return id;
	}
	
	public void setId(int id) {
		
		if(id > 0) {
			this.id = id;
		}
		else {
			throw new IllegalArgumentException("The ID should be a positive integer.");
		}
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		
		if(firstName.length() >= 3) {
			this.firstName = firstName;
		}
		else {
			throw new IllegalArgumentException("There must be at least 3 symbols.");
		}
		
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		
		if(lastName.length() >= 3) {
			this.lastName = lastName;
		}
		else {
			throw new IllegalArgumentException("There must be at least 3 symbols.");
		}
	}

	public java.util.Calendar getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(java.util.Calendar birthDate) {
		this.birthDate = birthDate;
	}
	
}
