
	//	Berker ÖNER 150122018

import java.util.Calendar;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class SalesEmployee extends RegularEmployee {
	
	private ArrayList<Product> sales;
	public static int numberOfSalesEmployees = 0;
	
	public SalesEmployee(int id, String firstName, String lastName, String gender,
			Calendar birthDate, String maritalStatus, String hasDriverLicence, double
			salary, Calendar hireDate, Department department, double pScore,
			ArrayList<Product> s) {
		
		super(id, firstName, lastName, gender, birthDate, maritalStatus, hasDriverLicence, salary, hireDate, department, pScore);
		this.sales = s;
		numberOfSalesEmployees++;
		
	}
	
	public SalesEmployee(RegularEmployee re, ArrayList<Product> s) {
		
		super(re.getId(), re.getFirstName(), re.getLastName(), re.getGender(), re.getBirthDate(), re.getMaritalStatus(),
				re.getHasDriverLicence(), re.getSalary(), re.getHireDate(), re.getDepartment(), re.getPerformanceScore());
		this.sales = s;
		numberOfEmployees++;
	}
	
	public boolean addSale(Product s) {
		return sales.add(s);
	}
	
	public boolean removeSale(Product s) {
		return sales.remove(s);
	}
	
	public ArrayList<Product> getSales(){
		return sales;
	}
	
	public static int getNumberOfSalesEmployees() {
		return numberOfSalesEmployees;
	}
	
	public void setSales(ArrayList<Product> sales) {
		this.sales = sales;
	}
	
	@Override
	public String toString() {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String formattedDate = dateFormat.format(getHireDate().getTime());
		
		return "\t\t\t2. SalesEmployee\n" + "\t\t\t\tPerson Info [id=" + super.getId() + ", firstName=" + super.getFirstName() + ", lastName=" +super.getLastName() + ", gender=" + super.getGender() + "]\n" + 
		"\t\t\t\tEmployee Info [salary=" + getSalary() + ", hireDate=" + formattedDate + "]\n" + 
		"\t\t\t\tRegularEmployee Info [performanceScore=" + getPerformanceScore() + ", bonus=" + getBonus() + "]";
				
	}

	public boolean hasMaxSales() {
	    double maxSales = 0;
	    for (Product product : sales) {
	        maxSales = Math.max(maxSales, product.getPrice());
	    }
	    return maxSales >= 10000;
	}

	
}
