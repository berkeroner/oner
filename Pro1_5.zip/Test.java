

/*     Berker ÖNER 150122018
 * 
 * 
 * 			input.txt dosyasını Java'da okutamadığım için değerleri kendim girip nesneleri kendim oluşturmak zorunda kaldım.
 * 
 * 
 */



import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.util.*;

public class Test {
    public static void main(String[] args) throws FileNotFoundException {
        
        List<Department> departments = new ArrayList<>();
        List<Project> projects = new ArrayList<>();
        List<Product> products = new ArrayList<>();
        
        FileOutputStream test1 = new FileOutputStream("test1.txt");
        
        try(test1){
    	
        	Department department1 = new Department(1, "Accounting");
        	departments.add(department1);
        	System.out.print(department1);
        	
        	Department department2 = new Department(2, "Marketing");
        	departments.add(department2);
        	
        	Calendar manager1BirthDate = Calendar.getInstance();
            manager1BirthDate.set(1982, Calendar.JUNE, 9);
            
            Calendar manager2BirthDate = Calendar.getInstance();
            manager2BirthDate.set(1967, Calendar.DECEMBER, 17);
        	
            
            
            Calendar manager1HireDate = Calendar.getInstance();
            manager1HireDate.set(2000, Calendar.DECEMBER, 17);
            
            Calendar manager2HireDate = Calendar.getInstance();
            manager2HireDate.set(2000, Calendar.DECEMBER, 17);
                      
            
            Manager manager1 = new Manager(123, "Mehmet", "Ari", "man", manager1BirthDate, "single", "yes", 150000, manager1HireDate, department1, 150000);
            System.out.print(manager1);
            
            Calendar developer1BirthDate = Calendar.getInstance();
            developer1BirthDate.set(1986, Calendar.MAY, 5);
            Calendar developer1HireDate = Calendar.getInstance();
            developer1HireDate.set(2017, Calendar.OCTOBER, 10);
            
            Calendar projectStartDate1 = Calendar.getInstance();
            projectStartDate1.set(2022, Calendar.MAY, 1);
            Project projectCreditCard = new Project("CreditCard", projectStartDate1, false);
            projects.add(projectCreditCard);
            
            Calendar projectStartDate2 = Calendar.getInstance();
            projectStartDate2.set(2021, Calendar.MAY, 1);
            Project projectRobotic = new Project("Robotic", projectStartDate2, true);
            projects.add(projectRobotic);

            ArrayList<Project> developer1Project = new ArrayList<>();
            developer1Project.add(projectCreditCard);
            developer1Project.add(projectRobotic);
            
            

            Developer developer1 = new Developer(111, "Ayse", "Caliskan", "woman", developer1BirthDate, "married", "yes",
            		35000, developer1HireDate, department1, 25, developer1Project);
            System.out.println(developer1);
            developer1.toString();
            
            
            System.out.print("\t\t\t\t[" + projectCreditCard + ", ");
            System.out.println(projectRobotic);

            Calendar salesEmployee1HireDate = Calendar.getInstance();
            salesEmployee1HireDate.set(2015, Calendar.FEBRUARY, 14);
            
            Calendar startDate11 = Calendar.getInstance();
            startDate11.set(2023, Calendar.JANUARY, 1);
            Product product11 = new Product("Product1", startDate11, 10000);
            products.add(product11);
            
            Calendar startDate55 = Calendar.getInstance();
            startDate55.set(2023, Calendar.JANUARY, 11);
            Product product55 = new Product("Product5", startDate55, 90000);
            products.add(product55);
            
            ArrayList<Product> salesEmployee1Products = new ArrayList<>();
            salesEmployee1Products.add(product55);
            salesEmployee1Products.add(product11);
            
            SalesEmployee salesEmployee1 = new SalesEmployee(167, "Serkan", "Yildiz", "man",
            		developer1BirthDate, "married", "yes",
        			75000, salesEmployee1HireDate, department1, 50,
        			salesEmployee1Products);
            System.out.println(salesEmployee1);
            
            System.out.print("\t\t\t\t[" + product55 + ", ");
            System.out.println(product11);

            
            Calendar regularEmployee1HireDate = Calendar.getInstance();
            regularEmployee1HireDate.set(2018, Calendar.NOVEMBER, 15);
            
            RegularEmployee regularEmployee1 = new RegularEmployee(156, "Bulut", "Karadag", "man",
            		developer1BirthDate, "single", "yes",
        			45000, regularEmployee1HireDate, department1, 75);
            System.out.println(regularEmployee1);
            
            
            
            
            System.out.print(department2);
            Manager manager2 = new Manager(256, "Arzu", "Ozturk", "woman", manager2BirthDate, "married", "yes", 200000, manager2HireDate, department2, 200000);
            System.out.print(manager2);
            
            Calendar developer2BirthDate = Calendar.getInstance();
            developer2BirthDate.set(1986, Calendar.MAY, 5);
            Calendar developer2HireDate = Calendar.getInstance();
            developer2HireDate.set(2017, Calendar.OCTOBER, 10);
            
            Calendar projectStartDate3 = Calendar.getInstance();
            projectStartDate3.set(2023, Calendar.JULY, 1);
            Project projectLLM = new Project("LLM", projectStartDate3, true);
            projects.add(projectLLM);
            
            Calendar projectStartDate4 = Calendar.getInstance();
            projectStartDate4.set(2023, Calendar.SEPTEMBER, 1);
            Project projectSpeechRecognition = new Project("SpeechRecognition", projectStartDate4, true);
            projects.add(projectSpeechRecognition);
            
            Calendar projectStartDate5 = Calendar.getInstance();
            projectStartDate5.set(2023, Calendar.NOVEMBER, 1);
            Project projectATM = new Project("ATM", projectStartDate5, true);
            projects.add(projectATM);

            ArrayList<Project> developer2Project = new ArrayList<>();
            developer2Project.add(projectLLM);
            developer2Project.add(projectSpeechRecognition);
            developer2Project.add(projectATM);
            
            Developer developer2 = new Developer(247, "Fatma", "Esin", "woman", developer1BirthDate, "single", "yes",
            		50000, developer2HireDate, department1, 80, developer2Project);
            System.out.println(developer2);
            developer2.toString();
            
            Calendar developer2StartDate1 = Calendar.getInstance();
            developer2StartDate1.set(2023, Calendar.JANUARY, 1);
            Product developer2Product1 = new Product("Product1", developer2StartDate1, 10000);
            products.add(developer2Product1);
            
            Calendar developer2StartDate2 = Calendar.getInstance();
            developer2StartDate2.set(2023, Calendar.FEBRUARY, 1);
            Product developer2Product2 = new Product("Product2", developer2StartDate2, 1500);
            products.add(developer2Product2);
            
            Calendar developer2StartDate3 = Calendar.getInstance();
            developer2StartDate3.set(2023, Calendar.NOVEMBER, 1);
            Product developer2Product3 = new Product("Product3", developer2StartDate3, 15000);
            products.add(developer2Product3);
            
            ArrayList<Product> salesEmployee2Products = new ArrayList<>();
            salesEmployee2Products.add(developer2Product1);
            salesEmployee2Products.add(developer2Product2);
            salesEmployee2Products.add(developer2Product3);
            
            Calendar salesEmployee2HireDate = Calendar.getInstance();
            salesEmployee2HireDate.set(2014, Calendar.MAY, 24);
            
            SalesEmployee salesEmployee2 = new SalesEmployee(213, "Mustafa", "Emir", "man",
            		developer1BirthDate, "married", "yes",
        			100000, salesEmployee2HireDate, department2, 100,
        			salesEmployee2Products);
            System.out.println(salesEmployee2);
            
            System.out.println("\n\n\n**********************CUSTOMERS************************");
            
            Calendar startDate1 = Calendar.getInstance();
            startDate1.set(2023, Calendar.JANUARY, 1);
            Product product1 = new Product("Product1", startDate1, 10000);
            products.add(product1);
            
            Calendar startDate2 = Calendar.getInstance();
            startDate2.set(2023, Calendar.FEBRUARY, 1);
            Product product2 = new Product("Product2", startDate2, 1500);
            products.add(product2);
            
            Calendar startDate3 = Calendar.getInstance();
            startDate3.set(2023, Calendar.NOVEMBER, 1);
            Product product3 = new Product("Product3", startDate3, 15000);
            products.add(product3);
            
            Calendar startDate4 = Calendar.getInstance();
            startDate4.set(2024, Calendar.APRIL, 1);
            Product product4 = new Product("Product4", startDate4, 50000);
            products.add(product4);
            
            Calendar startDate5 = Calendar.getInstance();
            startDate5.set(2023, Calendar.JANUARY, 11);
            Product product5 = new Product("Product5", startDate5, 90000);
            products.add(product5);
            
            ArrayList<Product> customer1Products = new ArrayList<>();
            customer1Products.add(product1);
            customer1Products.add(product2);
            customer1Products.add(product5);
            
            ArrayList<Product> customer2Products = new ArrayList<>();
            customer2Products.add(product3);

            ArrayList<Product> customer3Products = new ArrayList<>();
            customer3Products.add(product2);
            customer3Products.add(product3);
            
            
            Calendar customerBirthDate1 = Calendar.getInstance();
            customerBirthDate1.set(1988, Calendar.FEBRUARY, 1);

            Calendar customerBirthDate2 = Calendar.getInstance();
            customerBirthDate2.set(1988, Calendar.JULY, 9);

            Calendar customerBirthDate3 = Calendar.getInstance();
            customerBirthDate3.set(1988, Calendar.NOVEMBER, 28);
            
            Customer customer1 = new Customer(224, "Hacer", "Paksoy", "woman", customerBirthDate1, "married", "yes", customer1Products);
            System.out.println(customer1);
            
            Customer customer2 = new Customer(267, "Selin", "Ergul", "woman", customerBirthDate2, "single", "no", customer2Products);
            System.out.println(customer2);
            
            Customer customer3 = new Customer(178, "Cevdet", "Balci", "man", customerBirthDate3, "married", "no", customer3Products);
            System.out.println(customer3);

            
            System.out.println("\n\n**********************PEOPLE************************");
            
            Calendar personBirthDate2 = Calendar.getInstance();
            personBirthDate2.set(1988, Calendar.JUNE, 9);
            Person person2 = new Person(145, "Ismail", "Celik", "man", personBirthDate2, "married", "yes");
            
            Calendar personBirthDate3 = Calendar.getInstance();
            personBirthDate3.set(1967, Calendar.JANUARY, 9);
            Person person3 = new Person(189, "Taner", "Eser", "man", personBirthDate3, "single", "yes");
            
            Calendar personBirthDate4 = Calendar.getInstance();
            personBirthDate4.set(1989, Calendar.SEPTEMBER, 24);
            Person person4 = new Person(236, "Ela", "Kara", "woman", personBirthDate4, "married", "no");
            
            System.out.println(person2 + "\n" + person3 + "\n" + person4);
        }
        
        catch (Exception ex) {
        	System.out.println(ex + "ae");
        }
        
    }
}