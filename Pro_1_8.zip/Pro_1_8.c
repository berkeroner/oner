
		//	Berker �NER 150122018
			
			//	Verilen input'lara g�re son k�s�mda barks(1) yazd�rmada sorun var, o k�sm� nas�l d�zeltece�imi anlayamad�m.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct String{
	
	char str[25];
	int count;
	struct String* nextAlpha;
	struct String* nextCount;
	
} String;


void inc(String** headAlpha, String** headCount, char* key) {
	
	String* temp = NULL;
	
	String* present = *headAlpha;
	String* prev = NULL;
	
	while(present != NULL && strcmp(present->str, key) != 0){
		prev = present;
		present = present->nextAlpha;
	}
	
	if(present != NULL) {
		
		present->count = present->count + 1;
		
		if(prev){
			prev->nextAlpha = present->nextAlpha;
		}
		else {
			*headAlpha = present->nextAlpha;
		}
		
		temp = *headAlpha;
		prev = NULL;
		
		while(temp != NULL && strcmp(temp->str, key) < 0){
			prev = temp;
			temp = temp->nextAlpha;
		}
		
		if(prev){
			present->nextAlpha = prev->nextAlpha;
			prev->nextAlpha = present;
		}
		else {
			present->nextAlpha = *headAlpha;
			*headAlpha = present;
		}
		
		
		temp = *headCount;
		prev = NULL;
		
		while(temp != NULL && strcmp(temp->str, key) != 0){
			prev = temp;
			temp = temp->nextCount;
		}
		
		if(prev){
			prev->nextCount = present->nextCount;
		}
		
		else {
			*headCount = present->nextCount;
		}
		
		temp = *headCount;
		prev = NULL;
		
		while(temp != NULL && temp->count >= present->count){
			prev = temp;
			temp = temp->nextCount;
		}
		
		if(prev){
			present->nextCount = prev->nextCount;
			prev->nextCount = present;
		}
		
		else{
			present->nextCount = *headCount;
			*headCount = present;
		}
		
	}
	
	else {

        String* newNode = (String*)malloc(sizeof(String));
        strcpy(newNode->str, key);
        newNode->count = 1;
        newNode->nextAlpha = NULL;
        newNode->nextCount = NULL;

        present = *headAlpha;
        prev = NULL;
        
        while (present != NULL && strcmp(present->str, key) < 0) {
            prev = present;
            present = present->nextAlpha;
        }

        if (prev) {
            newNode->nextAlpha = prev->nextAlpha;
            prev->nextAlpha = newNode;
        }
		
		else {
            newNode->nextAlpha = *headAlpha;
            *headAlpha = newNode;
        }


        present = *headCount;
        prev = NULL;
        
        while (present != NULL && present->count >= newNode->count) {
            prev = present;
            present = present->nextCount;
        }

        if (prev) {
            newNode->nextCount = prev->nextCount;
            prev->nextCount = newNode;
        }
		
		else {
            newNode->nextCount = *headCount;
            *headCount = newNode;
        }
    }
	
}


void dec(String** headAlpha, String** headCount, char* key) {
	
	String* present = *headAlpha;
	String* prev = NULL;
	
	while(present != NULL && strcmp(present->str, key) != 0){
		prev = present;
		present = present->nextAlpha;
	}
	
	if(present != NULL){
		present->count = present->count - 1;
		
		if(present->count == 0){
			if(prev){
				prev->nextAlpha = present->nextAlpha;
			}
			
			else {
				*headAlpha = present->nextAlpha;
			}
			
			String* temp = *headCount;
			prev = NULL;
			
			while(temp != NULL && strcmp(temp->str, key) != 0){
				prev = temp;
				temp = temp->nextCount;
			}
			
			if(prev) {
				prev->nextCount = present->nextCount;
			}
			
			else {
				*headCount = present->nextCount;
			}

		}
		
		else {
			
			if(prev){
				prev->nextAlpha = present->nextAlpha;
			}
			else {
				*headAlpha = present->nextAlpha;
			}
			
			
			String* temp = *headAlpha;
			prev = NULL;
			
			while(temp != NULL && strcmp(temp->str, key) < 0){
				prev = temp;
				temp = temp->nextAlpha;
			}
			
			if(prev) {
				present->nextAlpha = prev->nextAlpha;
				prev->nextAlpha = present;
			}
			
			else {
				present->nextAlpha = *headAlpha;
				*headAlpha = present;
			}

			temp =*headCount;
			prev = NULL;
			while(temp != NULL && temp->count >= present->count){
				prev = temp;
				temp =temp->nextCount;
			}
			
			if (prev){
				present->nextCount = prev->nextCount;
				prev->nextCount = present;
			}
			else{
				present->nextCount = *headCount;
				*headCount = present;
			}
		}
		
	}
	
}


char* getMaxKey(String* head) {
	
	String* maxKey = head;
	String* current = head->nextCount;
	
		if(head == NULL){
		return "";
	}
	
	while(current != NULL) {
		
		if(current->count > maxKey->count) {
			maxKey = current;
		}
		
		else if(current->count == maxKey->count){
			if(maxKey->str > current->str){
				maxKey = current;
			}
		}
		current = current->nextCount;
	}
	return maxKey->str;
}


char* getMinKey(String* head){
	
	String* minKey = head;
	String* current = head->nextAlpha;
	
	if(head == NULL){
		return "";	
	}
	
	while(current != NULL){
		if(current->count < minKey->count){
			minKey = current;
		}
		
		else if(current->count == minKey->count) {
			if(minKey->str > current->str) {
				minKey = current;
			}
		}
		
		current = current->nextAlpha;
	}
	return minKey->str;
}


char* printList(String* head, int type) {
	
	String* present = head;
	
	if(type == 1){
		printf("\nThe list in alphabetical order:\n");
		
		while(present != NULL){
			printf("%s(%d) --> ", present->str, present->count);
			present = present->nextAlpha;
		}
		printf("NULL\n");
	}
	
	else if(type == 2){
		printf("\nThe list in descending order:\n");
		
		while(present != NULL) {
			printf("%s(%d) --> ", present->str, present->count);
			present = present->nextCount;
		}
		printf("NULL\n");
	}
}


int main() {
	
    String* headAlpha = NULL;
    String* headCount = NULL;

    FILE *file = fopen("input.txt", "r");

    char command[25];
    char key[25];
    int type;
    char line[100];

    while (fgets(line, sizeof(line), file)) {
    	
        sscanf(line, "%s", command);
        
        if (strcmp(command, "inc") == 0) {
            sscanf(line + strlen(command) + 1, "%s", key);
            inc(&headAlpha, &headCount, key);
        }
        
		else if (strcmp(command, "dec") == 0) {
            sscanf(line + strlen(command) + 1, "%s", key);
            dec(&headAlpha, &headCount, key);
        }
        
		else if (strcmp(command, "getMaxKey") == 0){
            printf("%s\n", getMaxKey(headCount));
        }
        
		else if (strcmp(command, "getMinKey") == 0) {
            printf("%s\n", getMinKey(headAlpha));
        }
        
		else if (strcmp(command, "printList") == 0) {
            sscanf(line + strlen(command) + 1, "%d", &type);
            
            if(type == 1){
            	printList(headAlpha, 1);
			}
			else if(type == 2) {
				printList(headCount, 2);
			}
        }
    }

    fclose(file);

}

