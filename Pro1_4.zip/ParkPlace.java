// Berker ÖNER 150122018

public class ParkPlace {

	private int size;
	private Vehicle vehicle;

	public ParkPlace(Vehicle vehicle) {
		this.size = vehicle.getSize();
		this.vehicle = vehicle;
	}

	public int getSize() {
		return size;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

}