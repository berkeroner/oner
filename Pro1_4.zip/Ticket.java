// Berker ÖNER 150122018

import java.util.Date;

public class Ticket {
	private Vehicle vehicle;
	private Date entryDate;
	private Date exitDate;
	private double totalPrice;
	int numberOfTickets;

	public Ticket(Vehicle vehicle, Date entryDate) {
		this.vehicle = vehicle;
		this.entryDate = entryDate;
	}

	public double calculatePrice(double hourlyPrice, Date exitDate) {
		this.exitDate = exitDate;
		long miliseconds = exitDate.getTime() - entryDate.getTime();
		double numberOfHours = Math.ceil(miliseconds / (3600000.0));
		totalPrice = vehicle.getSize() * hourlyPrice * numberOfHours;
		return totalPrice;
	}

	public String getTicketInfo() {

		String ticketInfo = "Ticket Info \nPlate Number : " + vehicle.getPlateNumber() + "\nEntry : "
				+ getEntryDate().toString();
		String output = " ";

		if (exitDate != null) {
			output = "\nExit : " + exitDate.toString() + "\nHour : "
					+ (exitDate.getTime() - getEntryDate().getTime()) / (3600000) + "\nFee : " + totalPrice;

		}

		return (ticketInfo + output + " ");
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public double getPrice() {
		return totalPrice;
	}

	public Date getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(Date entryDate) {
		this.entryDate = entryDate;
	}

}
