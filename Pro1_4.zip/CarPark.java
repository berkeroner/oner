// Berker ÖNER 150122018

import java.util.Date;

public class CarPark {
	private int capacity;
	private ParkPlace[] parkPlaceArray;
	private Ticket[] ticketArray;
	private double hourlyPrice;
	private int numberOfTickets;

	public CarPark(int capacity, double hourlyPrice) {
		this.capacity = capacity;
		this.parkPlaceArray = new ParkPlace[capacity];
		this.ticketArray = new Ticket[capacity];
		this.hourlyPrice = hourlyPrice;
		this.numberOfTickets = 0;
	}

	public Ticket parkVehicle(Vehicle vehicle, Date entryDate) {

		for (int i = 0; i < capacity; i++) {
			if (parkPlaceArray[i] == null) {
				parkPlaceArray[i] = new ParkPlace(vehicle);
				System.out.println("The vehicle with " + vehicle.getPlateNumber() + " plate number is parked.");
				Ticket ticket = new Ticket(vehicle, entryDate);
				ticketArray[numberOfTickets++] = ticket;
				return ticket;
			}
		}

		System.out.println("Car park is full!");
		return null;
	}

	public Vehicle exitVehicle(Ticket ticket, Date exitDate) {
		for (int i = 0; i < capacity; i++) {
			if (parkPlaceArray[i] != null
					&& parkPlaceArray[i].getVehicle().getPlateNumber().equals(ticket.getVehicle().getPlateNumber())) {
				ticket.calculatePrice(hourlyPrice, exitDate);

				System.out.println("The price for vehicle with " + ticket.getVehicle().getPlateNumber()
						+ " plate number is: " + ticket.getPrice() + " TLs");

				parkPlaceArray[i] = null;
				return ticket.getVehicle();
			}
		}

		return null;
	}

	public double getTotalIncome() {
		double totalIncome = 0;
		for (int i = 0; i < numberOfTickets; i++) {
			totalIncome += ticketArray[i].getPrice();
		}
		return totalIncome;
	}

	public void printVehicleList() {
		for (ParkPlace parkPlace : parkPlaceArray) {
			if (parkPlace != null) {
				System.out.println(parkPlace.getVehicle().getVehicleInfo());
			} else if (numberOfTickets > capacity) {
				System.out.println("Car park is full !");
			}
		}
	}

	public void printTickets() {

		for (int i = 4; i < numberOfTickets; i++) {
			Ticket ticket = ticketArray[i];
			System.out.println(ticket.getTicketInfo());

		}

	}

}
