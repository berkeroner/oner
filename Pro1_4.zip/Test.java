// Berker ÖNER 150122018

import java.util.Date;

public class Test {
	public static void main(String[] args) {
		CarPark park = new CarPark(10, 5);

		Date entryDate = new Date();

		Vehicle vehicle1 = new Vehicle("11AA111", 4);
		Vehicle vehicle2 = new Vehicle("11BB222", 2);
		Vehicle vehicle3 = new Vehicle("11CC333", 1);
		Vehicle vehicle4 = new Vehicle("11DD444", 2);
		Vehicle vehicle5 = new Vehicle("11EE555", 4);

		park.parkVehicle(vehicle1, entryDate);
		park.parkVehicle(vehicle2, new Date(entryDate.getTime() + 3600000));
		park.parkVehicle(vehicle3, new Date(entryDate.getTime() + 2 * 3600000));
		park.parkVehicle(vehicle4, new Date(entryDate.getTime() + 3 * 3600000));

		park.printVehicleList();

		Date exitDate1 = new Date(entryDate.getTime() + 5 * 3600000);
		Date exitDate2 = new Date(entryDate.getTime() + 6 * 3600000);

		park.exitVehicle(park.parkVehicle(vehicle1, entryDate), exitDate1);
		park.exitVehicle(park.parkVehicle(vehicle2, new Date(entryDate.getTime() + 3600000)), exitDate2);

		park.printVehicleList();

		park.exitVehicle(park.parkVehicle(vehicle3, new Date(entryDate.getTime() + 2 * 3600000)),
				new Date(entryDate.getTime() + 7 * 3600000));
		park.exitVehicle(park.parkVehicle(vehicle4, new Date(entryDate.getTime() + 3 * 3600000)),
				new Date(entryDate.getTime() + 8 * 3600000));

		System.out.println("Total Income: " + park.getTotalIncome() + " TLs");
		park.printTickets();
	}
}
