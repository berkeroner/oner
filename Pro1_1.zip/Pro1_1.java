
public class Pro1_150122018 {

	public static void main(String[] args) {
		
		System.out.println("                                     OO    OO             ");
		System.out.println("                                     OO    OO             ");
		System.out.println("                                                          ");
		System.out.println("BBBBBBBBBBBBBB                    OOOOOOOOOOOOOO          ");
		System.out.println("BB            BB                OO              OO        ");
		System.out.println("BB              BB             OO                 OO      ");
		System.out.println("BB               BB           OO                   OO     ");
		System.out.println("BB                BB         OO                     OO    ");
		System.out.println("BB                BB        OO                       OO   ");
		System.out.println("BB               BB        OO                         OO  ");
		System.out.println("BB             BB         OO                           OO ");
		System.out.println("BBBBBBBBBBBBBBB           OO                           OO ");
		System.out.println("BB             BB         OO                           OO ");
		System.out.println("BB              BB         OO                         OO  ");
		System.out.println("BB               BB         OO                       OO   ");
		System.out.println("BB                BB         OO                     OO    ");
		System.out.println("BB                BB          OO                   OO     ");
		System.out.println("BB               BB            OO                 OO      ");
		System.out.println("BB             BB               OO               OO       ");
		System.out.println("BBBBBBBBBBBBBBB                   OOOOOOOOOOOOOOO         ");
		
		// TODO Auto-generated method stub

	}

}