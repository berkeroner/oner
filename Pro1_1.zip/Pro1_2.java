
import java.util.Scanner ;

public class Pro2_150122018 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the value of x1 : ");
		double x1 = input.nextDouble();
		
		System.out.print("Enter the value of y1 : ");
		double y1 = input.nextDouble();
		
		System.out.print("Enter the value of x2 : ");
		double x2 = input.nextDouble();
		
		System.out.print("Enter the value of y2 : ");
		double y2 = input.nextDouble();
		
		double slope = ((y2 - y1) / (x2 - x1));
		
		double xmid = ((x1 + x2) / 2 );
		double ymid = ((y1 + y2) / 2 );
		
		double m = (int) -((1/slope) * 100) / 100.0 ;
		
		double b = (int)((ymid - m * xmid) * 100) / 100.0 ;
		
		
		System.out.print("The equation of the perpendicular bisector of the line segment between " +
				"(" + x1 + ", " + y1 + ")" + " and " + "(" + x2 + ", " + y2 + ")" +
				" is" + " y = " + m + "x + " + b );
		
		
		// TODO Auto-generated method stub

	}

}