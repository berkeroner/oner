
import java.util.Scanner;

public class Pro3_150122018 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the first number : ");
		double firstnumber = input.nextDouble() ;
		
		System.out.print("Enter the operator (+, -, *, /) : ");
		String operator = input.next() ;
		
		System.out.print("Enter the second number : ") ;
		double secondnumber = input.nextDouble() ;
		
		if (operator.equals ("+")) {
			System.out.println("Result : " + (int)((firstnumber + secondnumber) * 100) / 100.0) ;
		}
		
		else if (operator.equals ("-"))
			System.out.println("Result : " + (int)((firstnumber - secondnumber) * 100) / 100.0) ;
		
		else if (operator.equals ("*"))
			System.out.println("Result : " + (int)((firstnumber * secondnumber) * 100) / 100.0) ;
		
		else if (operator.equals ("/"))
			if (secondnumber == 0) {
				System.out.println("Error: Division by zero is not allowed.") ;
			}
			else
				System.out.println("Result : " + (int)((firstnumber / secondnumber) * 100) / 100.0);
		
		else
			System.out.println("Invalid operator. Please enter +, -, *, or /.");
	}
}
		// TODO Auto-generated method stub