// Berker ÖNER 150122018

import java.util.Scanner;

public class Pro3_150122018 {

	public static void main(String[] args) {

		while (true) {
		System.out.println("Welcome to the Num-Char printer program ");
		System.out.println("=======================================");
		
		Scanner input = new Scanner(System.in);

		System.out.println("Enter the size : ");
		int size = input.nextInt();
		
		while (size <= 0) {
			
			System.out.println("Invalid size. Enter the size again : ");
			size = input.nextInt();
			
		}

		for (int a = 1; a <= size; a++) {

			for (int b = a; b < size; b++) {

				System.out.print(" ");

			}

			for (int c = 1; c <= a; c++) {

				System.out.print(c);
				
			}
			for (int d = a-2 ; d >= 0 ; d--) {
				
				String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
				char letter = alphabet.charAt(d);
				System.out.print(letter);
				
			}
			System.out.println("");
		
		}
		for (int a = size; a >= 1; a--) {

			for (int b = a; b <= size; b++) {

				System.out.print(" ");

			}

			for (int c = 1; c < a; c++) {

				System.out.print(c);

			}
			for (int d = a; d>=3 ; d--) {
				
				String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
				char letter = alphabet.charAt(d-3);
				System.out.print(letter);
				
			}

				System.out.println("");

		}
			
		System.out.println("Would you like to continue? (Y or N) : ");
		String again = input.next() ;
		char character = again.charAt(0);
				
		if (character == 'N' || character == 'n') {
			System.out.println("Program ends. Bye :) ") ;
			break;
			}
		}
	}
}