// Berker ÖNER 150122018

import java.util.Scanner; ;

public class Pro2_150122018 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter the length of the series : ");
		int length = input.nextInt();
		
		double first = 0 ;
		double second = 1 ;
		double thirth = 2 ;
		double repeat = 0 ;
		
		System.out.print("0.0 " + "1.0 " + "2.0 ");
		
		while ( repeat < (length - 3) ) {
			
			double x = Math.sin(first) ;
			double y = Math.cos(second) ;
			double z = Math.tan(thirth) ;
			
			double result = x + y + z ;
			
			System.out.print((int)(result * 100) / 100.0 + " ");
		
			first = second ;
			second = thirth ;
			thirth = result ;
					
			repeat++ ;
					
		}
	}
}