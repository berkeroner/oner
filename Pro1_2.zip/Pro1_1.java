// Berker ÖNER 150122018

import java.util.Scanner ;

public class Pro1_150122018 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter an integer number : ");
		int number = input.nextInt();
		
		int result = 0;
		int bits = 0;
		
		if (number == 0) {
			System.out.println("Program ends. Bye ");
			System.exit(1);
		}
		
		else if (number > 0) {
			while (number >= 1 ) {
				result = (number / 2);
				number = result;
				bits++ ;
			}
			System.out.println("The number of bits : " + bits);
		}
			
		else
			System.out.println("Illegal input. ");
			
	}
}